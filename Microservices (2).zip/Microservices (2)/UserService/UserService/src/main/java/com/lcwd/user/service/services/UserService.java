package com.lcwd.user.service.services;

import java.util.List;

import com.lcwd.user.service.entities.User;

public interface UserService {
	
	// save user
	 User saveUser(User user);

	//get all
	List<User> getAllUsers();
	
	
	//get single user of given userId
	User getUser(String userId);
		
	

}
