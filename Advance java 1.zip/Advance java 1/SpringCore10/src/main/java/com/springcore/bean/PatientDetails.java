package com.springcore.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class PatientDetails {
	
	@Value("shubham")
	private String name;
	
	@Value("shubzz@123")
	private String email;
	
	@Value("9970507109")
	private long contact;

}
