package com.springcore.main;

import java.io.ObjectInputFilter.Config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springcore.bean.DocterBean;
import com.springcore.config.DocterConfig;


public class DocterMain {
	
	public static void main(String[] args) {

		
		ApplicationContext context=new ClassPathXmlApplicationContext("Config.xml");  //mixed configuration annotation and xml used


		DocterBean bean=context.getBean(DocterBean.class);

				
			
				System.out.println(bean);
				
				((ClassPathXmlApplicationContext)context).close();

			}

}
