package com.springcore.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.springcore.bean.StudentBean;

@Configuration
@ComponentScan(basePackages = {"com.springcore.bean.StudentBean"})
public class StudeConfig {
	
	@Bean(name="stu")
	public StudentBean getStudentBean() {
		
		return new StudentBean();
	}

}
