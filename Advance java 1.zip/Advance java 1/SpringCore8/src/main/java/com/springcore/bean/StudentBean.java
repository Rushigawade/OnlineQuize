package com.springcore.bean;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class StudentBean {
	
	private int id;
	private String name;

}
