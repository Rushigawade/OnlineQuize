package com.springcore.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.springcore.bean.StudentBean;
import com.springcore.config.StudeConfig;



public class StudeMain {

	public static void main(String[] args) {

		
ApplicationContext context=new AnnotationConfigApplicationContext(StudeConfig.class);
		
		StudentBean student=(StudentBean) context.getBean("stu");
	    
		student.setId(5);
		student.setName("shubham");
		
	
		System.out.println(student);
		
		((AnnotationConfigApplicationContext)context).close();

	}

}
