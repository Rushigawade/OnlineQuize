package com.student.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sprng.bean.SpringCore3.StudentBean;

public class StudentDriver {

	public static void main(String[] args) {
		
		//try {
			
		
		
	//	ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("com/student/main/StudeConfig.xml");
	//	StudentBean s=(StudentBean) classPathXmlApplicationContext.getBean("student");
	//	System.out.println(s);
	//	} catch (Exception e) {
			// TODO: handle exception
	//		System.out.println("hello");
		//}
	ApplicationContext context=new ClassPathXmlApplicationContext("Studeconfig.xml");
		
		StudentBean bean=(StudentBean) context.getBean(StudentBean.class);
		
		System.out.println(bean);
		
		((ClassPathXmlApplicationContext)context).close();

	}

}