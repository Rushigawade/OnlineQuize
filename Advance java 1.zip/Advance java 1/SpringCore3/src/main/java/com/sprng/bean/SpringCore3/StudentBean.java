package com.sprng.bean.SpringCore3;

import lombok.Data;

@Data
public class StudentBean {
	
	private int rollno;
	private String name;
	private String Dob;
	
}
