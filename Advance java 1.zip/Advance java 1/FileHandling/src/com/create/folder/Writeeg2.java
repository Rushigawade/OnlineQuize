package com.create.folder;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Writeeg2 {

	public static void main(String[] args) {
		File f=new File("C:\\Users\\admin\\Desktop\\Rushi\\New.txt");
		
		FileWriter fw=null;
		
		try {
			fw=new FileWriter(f);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			fw.write("hey rushi you are created new file");  //    bridge
			fw.flush();                                      //send the data and stored data //not used flush not sending data 
			System.out.println("data is written");   
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		}
}
