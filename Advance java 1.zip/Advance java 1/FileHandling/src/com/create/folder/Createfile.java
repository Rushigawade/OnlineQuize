package com.create.folder;

import java.io.File;
import java.io.IOException;

public class Createfile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File f=new File("C:\\Users\\admin\\Desktop\\Rushi\\hello.txt");
		
		if (f.exists()==true) {
			
			System.out.println("file is alredy exist");
			
		} else {
			
			//to create new file
			
			try {
				f.createNewFile();
				
				System.out.println("created new file");
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
	}

}
