package com.create.folder;

import java.io.File;

public class CreateFolder {

	public static void main(String[] args) {
	
	File f=new File("C:\\Users\\admin\\Desktop\\Rushi");
	
	if (f.exists()==true) {
		System.out.println("Folder is already exist");
		
	} else {
		
		//create folder
		f.mkdir();
		System.out.println("folder created");

	}

	}

}
