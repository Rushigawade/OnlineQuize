package com.create.folder;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FilewritingExample {

	public static void main(String[] args) {
		
		String path="C:\\Users\\admin\\Desktop\\Rushi\\filewriting.txt";
		
		File file=new File(path);
		
		FileWriter fw=null;
		String content="hey rushi what are you doings ";
		try {
			fw=new FileWriter(file);
			fw.write(content);
			fw.flush();
			System.out.println("new file data writing");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
