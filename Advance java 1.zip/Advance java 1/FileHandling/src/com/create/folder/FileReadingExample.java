package com.create.folder;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FileReadingExample {

	public static void main(String[] args) {
		
		
        String path="C:\\Users\\admin\\Desktop\\Rushi\\filewriting.txt";
		
		File file=new File(path);
		
		FileReader fr=null;
		long length=file.length();
		
		//creating the array which we can store the data of the file
		
		char []c=new char[(int) length];
		try {
			
			fr=new FileReader(file);
			fr.read(c);
			
			System.out.println(c);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
