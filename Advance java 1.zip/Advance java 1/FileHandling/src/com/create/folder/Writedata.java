package com.create.folder;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Writedata {

	public static void main(String[] args) {
		String path="C:\\Users\\admin\\Desktop\\Rushi\\hello.txt";
		File file = new File(path);
		FileWriter fw=null;
		try {
			fw = new FileWriter(file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fw.write("Data is written");
			fw.flush();
			System.out.println("Data is written");

		} catch (IOException e) {

			e.printStackTrace();
		}
	}

}
