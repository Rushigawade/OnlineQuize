package com.task;

import java.io.Closeable;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class UserInputWriiteData {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Write data from the file");
		
		
		String str=sc.nextLine();
		
		
		String path="C:\\Users\\admin\\Desktop\\Rushi\\he.txt";
		File file = new File(path);
		FileWriter fw=null;
		
		String content=str;
		try {
			fw=new FileWriter(file);
			fw.write(content);
			fw.flush();
			System.out.println("data enter succesfully");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
		finally {
			try {
				fw.close();
			} catch (IOException e) {
				
				
				e.printStackTrace();
			}
		}

	}
}
