package com.task;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FolderMaximum {
	
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Write data from the file");
		
		
		String str=sc.nextLine();
		
		File f=new File("C:\\Users\\admin\\Desktop\\SQL");
		
		
		if (f.exists()==true) {
			System.out.println(" Sql Folder is already exist");
			
			File j=new File("C:\\Users\\admin\\Desktop\\SQL\\sqlQuetion");
			
			
				if (j.exists()==true) {
				System.out.println(" SQL Folder is already exist");
				
				System.out.println("data enter succesfully");
				
			} else {
				
				//create folder sqlQuetion
				j.mkdir();
				System.out.println("sql Quetion folder created");

			}
			
			File k=new File("C:\\Users\\admin\\Desktop\\SQL\\sqlQuetion\\sqlAnswers\\hey.txt");
			
			String content=str;
			FileWriter fw=null;
			if (k.exists()==true) {
				System.out.println("sqlAnswers Folder is already exist");
			
				try {
					fw=new FileWriter(k);
					fw.write(content);
					fw.flush();
					System.out.println("data enter succesfully");
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
			} else {
				
				//create folder sqlAnswers
				k.mkdir();
				System.out.println("sqlAnswers folder is created");

			}
			
			
			
		} else {
			
			//create folder Sql
			f.mkdir();
			System.out.println(" Sql folder is created");

		}
		
	
		

		}

	}


