package com.map.manyTOone.unidire.DAO;



	import javax.persistence.EntityManager;
	import javax.persistence.EntityManagerFactory;
	import javax.persistence.EntityTransaction;
	import javax.persistence.Persistence;

import com.Mapp_manyTOone_unidirectional.DTO.CompanyDTO;
import com.Mapp_manyTOone_unidirectional.DTO.EmployeeDTO;


	public class CompanyEmployeeDAO {
		
		private static EntityManagerFactory factory;
		private static EntityManager manager;
		private static EntityTransaction transaction;

		private static void openConnection() {

			factory = Persistence.createEntityManagerFactory("hibernate7");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();

		}

		private static void closeConnections() {
			factory.close();
			manager.close();

			try {
				transaction.rollback();

			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("transaction is commited");
			}

		}

		public static void main(String[] args) {
			
			openConnection();
			transaction.begin();
			
			CompanyDTO company=new CompanyDTO();
			company.setName("Virtusa");
			
			
			EmployeeDTO emp1=new EmployeeDTO();
			emp1.setName("Ajinath");
			
			EmployeeDTO emp2=new EmployeeDTO();
			emp2.setName("Rushi");
			
			EmployeeDTO emp3=new EmployeeDTO();
			emp3.setName("Akash");
			
			
			EmployeeDTO emp4=new EmployeeDTO();
			emp4.setName("Jyotsna");
			
			
			emp4.setCompany(company);
			emp3.setCompany(company);
			emp2.setCompany(company);
			emp1.setCompany(company);
			
			manager.persist(company);
			manager.persist(emp1);
			manager.persist(emp2);
			manager.persist(emp3);
			manager.persist(emp4);
			
			transaction.commit();
			closeConnections();

	}
	
}
