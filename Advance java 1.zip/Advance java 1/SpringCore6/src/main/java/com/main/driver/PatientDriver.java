package com.main.driver;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bean.dependancyInection.Patient;


public class PatientDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("Config.xml");
        Patient bean=(Patient) context.getBean(Patient.class);
		
		System.out.println(bean);
		
		((ClassPathXmlApplicationContext)context).close();

	}

}
