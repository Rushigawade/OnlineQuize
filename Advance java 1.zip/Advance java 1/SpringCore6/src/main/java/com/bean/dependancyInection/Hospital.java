package com.bean.dependancyInection;

import lombok.Data;

@Data
public class Hospital {
	private String name;
	private String address;
	private Medical details;

}
