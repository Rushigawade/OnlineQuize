package com.bean.dependancyInection;

import lombok.Data;

@Data
public class Medical {
	
	private String name;
	private String address;

}
