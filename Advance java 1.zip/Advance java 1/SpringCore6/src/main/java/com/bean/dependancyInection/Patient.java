package com.bean.dependancyInection;

import lombok.Data;

@Data
public class Patient {
	private int id;
	private String name;
	private Hospital detail;

}
