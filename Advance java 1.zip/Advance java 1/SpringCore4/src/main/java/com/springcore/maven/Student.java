package com.springcore.maven;

import lombok.Data;

@Data
public class Student {
	
	private int rollno;
	private String name;
	private String Dob;

}
