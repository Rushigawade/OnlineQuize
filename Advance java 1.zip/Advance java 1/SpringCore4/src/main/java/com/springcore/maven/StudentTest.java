package com.springcore.maven;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudentTest {

	public static void main(String[] args) {
		try {
			
		
		ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("com/springcore/maven/Studentconfig.xml");
			Student s=(Student) classPathXmlApplicationContext.getBean("student");
			System.out.println(s);
			} catch (Exception e) {
				// TODO: handle exception
			e.printStackTrace();
			}
	}
}
