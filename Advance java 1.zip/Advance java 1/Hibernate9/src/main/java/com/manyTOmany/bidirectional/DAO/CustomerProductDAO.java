package com.manyTOmany.bidirectional.DAO;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.manyTOmany.bidirectional.DTO.CustomerDTO;
import com.manyTOmany.bidirectional.DTO.ProductDTO;

public class CustomerProductDAO {
	
	private static EntityManagerFactory factory;
	private static EntityManager manager;
	private static EntityTransaction transaction;

	private static void openConnection() {

		factory = Persistence.createEntityManagerFactory("hibernate9");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();

	}

	private static void closeConnections() {
		factory.close();
		manager.close();

		try {
			transaction.rollback();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("transaction is commited");
		}

	}

	public static void main(String[] args) {
		
		openConnection();
		transaction.begin();
		
		ProductDTO product1=new ProductDTO();
		product1.setName("faceash");
		product1.setQuantity(45);
		product1.setPrice(55);
		
		
		ProductDTO product2=new ProductDTO();
		product2.setName("handwash");
		product2.setQuantity(45);
		product2.setPrice(55);
		
		CustomerDTO customer1=new CustomerDTO();
		customer1.setName("Rushi");
		customer1.setAddress("pune");
		customer1.setPhoneno(755879635l);
		

		CustomerDTO customer2=new CustomerDTO();
		customer2.setName("akash");
		customer2.setAddress("une");
		customer2.setPhoneno(755487795l);
		
		List<ProductDTO> products=Arrays.asList(product1,product2);
		customer1.setProducts(products);
		customer2.setProducts(products);
		
		List<CustomerDTO> customers=Arrays.asList(customer1,customer2);
		product1.setCustomers(customers);
		product2.setCustomers(customers);
		
		
		
		manager.persist(product1);
		manager.persist(product2);
		manager.persist(customer1);
		manager.persist(customer2);
		
		transaction.commit();
		closeConnections();

}
}