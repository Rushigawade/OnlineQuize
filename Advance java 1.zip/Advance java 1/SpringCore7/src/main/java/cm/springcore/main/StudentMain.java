package cm.springcore.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.springcore.bean.Student;
import com.springcore.configuration.StudentConfig;

public class StudentMain {

	public static void main(String[] args) {
		
		ApplicationContext context=new AnnotationConfigApplicationContext(StudentConfig.class);
		
		Student student=(Student) context.getBean("std");
	    
	/*	student.setId(1);
		student.setName("Akash");
		student.setAddress("Baradgaon");     //another way to add set values using @value annotation
		student.setContact(75587693l);
	*/
		System.out.println(student);
		
		((AnnotationConfigApplicationContext)context).close();
	}

}
