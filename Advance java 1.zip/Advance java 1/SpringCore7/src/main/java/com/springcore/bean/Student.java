package com.springcore.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class Student {

	@Value("1")
	private int id;
	@Value("rushi")
	private String name;
	@Value("Baradgaon")
	private String Address;
	@Value("7558769389")
	private long contact;
}
