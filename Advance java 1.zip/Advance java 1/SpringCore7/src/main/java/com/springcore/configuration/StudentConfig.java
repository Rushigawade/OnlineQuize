package com.springcore.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.springcore.bean.Student;

@Configuration
@ComponentScan(basePackages = {"com.springcore.bean.Student"})   //copy qualified name Student
public class StudentConfig {
	
	@Bean("std")
	public Student getStudent() {
		return new Student();
		
	}

}
