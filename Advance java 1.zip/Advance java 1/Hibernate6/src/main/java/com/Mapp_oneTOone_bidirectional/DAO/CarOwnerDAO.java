package com.Mapp_oneTOone_bidirectional.DAO;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.Mapp_oneTOone_bidirectional2.DTO.CarDTO;
import com.Mapp_oneTOone_bidirectional2.DTO.OwnerDTO;

public class CarOwnerDAO {
	
	private static EntityManagerFactory factory;
	private static EntityManager manager;
	private static EntityTransaction transaction;

	private static void openConnection() {

		factory = Persistence.createEntityManagerFactory("hibernate6");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();

	}

	private static void closeConnections() {
		factory.close();
		manager.close();

		try {
			transaction.rollback();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("transaction is commited");
		}

	}

	public static void main(String[] args) {
		
		openConnection();
		transaction.begin();
		
		CarDTO car1=new CarDTO();
		car1.setName("tatapunch");
		car1.setSpeed(85);
		
		OwnerDTO owner1=new OwnerDTO();
		owner1.setName("Rushi");
		owner1.setAge(35);
		
		car1.setOwner(owner1);
		owner1.setCar(car1);
		
		manager.persist(car1);
		manager.persist(owner1);
		
		
	System.out.println("------------------------------------------------------------------------");
	

	CarDTO car2=new CarDTO();
	car2.setName("Breeza");
	car2.setSpeed(80);
	
	OwnerDTO owner2=new OwnerDTO();
	owner2.setName("Rushi45");
	owner2.setAge(23);
	
	car2.setOwner(owner2);
	owner2.setCar(car2);
	
	
	manager.persist(car2);
	manager.persist(owner2);
	
	System.out.println("-----------------------------------------------------------------------------");
	

	CarDTO car3=new CarDTO();
	car1.setName("odi");
	car1.setSpeed(180);
	
	OwnerDTO owner3=new OwnerDTO();
	owner3.setName("Akash");
	owner3.setAge(60);
	
	 car3.setOwner(owner3);
	 owner3.setCar(car3);
		
		manager.persist(car3);
		manager.persist(owner3);
		
		transaction.commit();
		closeConnections();

}
}