package com.Mapp_oneTOone_bidirectional2.DTO;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="CarDetails")
public class CarDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Car_no")
	private int no;
	
	@Column(name="car_name")
	private String name;
	
	@Column(name="car_speed")
	private int speed;
	
	
	//@JoinTable(name = "Owner_Details", joinColumns = @JoinColumn(referencedColumnName = "Car_no"), 
   // inverseJoinColumns = @JoinColumn(referencedColumnName = "Owner_id"))
	@OneToOne(cascade=CascadeType.ALL)
	private OwnerDTO owner;
}
