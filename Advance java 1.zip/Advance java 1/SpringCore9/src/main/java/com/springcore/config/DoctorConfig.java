package com.springcore.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.springcore.bean.DocterBean;

@Configuration
@ComponentScan(basePackages = {"com.springcore.bean"})  //package name of DocterBean
public class DoctorConfig {
	
	@Bean("doct")
	public DocterBean getDocterBean(){
		
		return new DocterBean();
	}

}
