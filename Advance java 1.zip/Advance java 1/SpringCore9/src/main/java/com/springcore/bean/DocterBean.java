package com.springcore.bean;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class DocterBean {

	@Value("10")
	private int id;
	
	@Value("Rushi")
	private String name;
	
	@Value("Bardgaon")
	private String Address;
	
	@Autowired
	private PatientDetails details;
}
