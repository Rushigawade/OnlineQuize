package com.springcore.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class PatientDetails {
	
	@Value("110")
	private int id;
	
	@Value("nagesh")
	private String name;
	
	@Value("solapur")
	private String Address;

}
