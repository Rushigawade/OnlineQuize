package com.springcore.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.springcore.bean.DocterBean;
import com.springcore.config.DoctorConfig;



public class DoctorMain {
	public static void main(String[] args) {

		
ApplicationContext context=new AnnotationConfigApplicationContext(DoctorConfig.class);


DocterBean docter=(DocterBean) context.getBean("doct");

		
	
		System.out.println(docter);
		
		((AnnotationConfigApplicationContext)context).close();

	}

}


