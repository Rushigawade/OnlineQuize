package com.maven.springframework.SpringCore;

public class Employee {
	private String name;
	private String empid;
	private double sal;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", empid=" + empid + ", sal=" + sal + ", getName()=" + getName()
				+ ", getEmpid()=" + getEmpid() + ", getSal()=" + getSal() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
