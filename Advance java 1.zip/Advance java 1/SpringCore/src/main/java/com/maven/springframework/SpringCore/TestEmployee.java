package com.maven.springframework.SpringCore;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("com\\maven\\springframework\\SpringCore\\E1.xml");  //copy qualified name of E1.xml 
       
		Employee emp =(Employee) ctx.getBean("employee");																																																																																																											
		
		System.out.println(emp);                                                 
		
	}

}
