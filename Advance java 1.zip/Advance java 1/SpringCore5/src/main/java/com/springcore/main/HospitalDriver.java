package com.springcore.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springcore.bean.HospitalBean;


public class HospitalDriver {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("Hospiconfig.xml");
        HospitalBean bean=(HospitalBean) context.getBean(HospitalBean.class);
		
		System.out.println(bean);
		
		((ClassPathXmlApplicationContext)context).close();

		

	}

}
