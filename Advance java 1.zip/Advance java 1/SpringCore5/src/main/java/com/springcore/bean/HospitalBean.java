package com.springcore.bean;

import lombok.Data;

@Data
public class HospitalBean {
	
	private int id;
	private String name;
	private String email;
	private long contact;
	
	
	
	public HospitalBean(int id, String name, String email, long contact) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.contact = contact;
	}
	
	
	

}
