package runnable.threads;

public class Task {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Runnable r1 = () -> {

			System.out.println("player chance 1");

		};

		Runnable r2 = () -> {

			System.out.println("player chance 2");

		};

		Runnable r3 = () -> {

			System.out.println("player chance 3");

		};

		Runnable r4 = () -> {

			System.out.println("player chance 4");

		};

		Runnable r5 = () -> {
			

				System.out.println("Player chance 5");

			
		};
		
		Thread a=new Thread(r1);
		a.start();
		
		
		Thread a2=new Thread(r2);
		a2.start();
		
		Thread a3=new Thread(r3);
		a3.start();
		
		Thread a4=new Thread(r4);
		a4.start();
		
		Thread a5=new Thread(r5);
		a5.start();
		
	}

}
