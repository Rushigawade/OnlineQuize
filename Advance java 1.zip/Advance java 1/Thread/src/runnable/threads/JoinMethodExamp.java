package runnable.threads;

public class JoinMethodExamp {

	public static void main(String[] args) {
		
				
				Runnable r=()->{
					
					for (int i=0;i<=20;i++) {
					
					System.out.println("First thread runnning");
				}

			};
			
			
			
			
			Runnable r1=()->{
				
				  
				for (int i=0;i<=20;i++) {
				
				System.out.println("second thread runnning");
			}

		};

		Runnable r2=()->{
			
			for (int i=0;i<=20;i++) {
			
			System.out.println("Third thread runnning");
		}

		};


		Thread a=new Thread(r);
		Thread a1=new Thread(r1);
		Thread a2=new Thread(r2);

		a.start();
        try {
			a.join();                         // join method used first thread then first thread execute completlys
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}                                        
		a1.start();
		a1.setPriority(10);

		a2.start();

			}
		}																																																																																																																																																																																			
			
		
