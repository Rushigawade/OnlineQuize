package runnable.threads;

public class TestRunnaable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
  
		
		Runnable r=()->  // lambda expression               using lambda expression due to avoid so many no of codes lines
		{
			for (int i = 0; i < 10; i++) {
				
				System.out.println("First thread execute");
				
			}
		};
		
		Runnable r1=()->
		{
			for (int i = 0; i < 10; i++) {
				
				System.out.println("Second thread execute");
				
			}
		};
		
		new Thread(()-> System.out.println("Hello")).start();
		
		
		Thread thread1=new Thread(r);
		thread1.start();
		
		Thread thread2=new Thread(r1);
		thread2.start();

	}

}
