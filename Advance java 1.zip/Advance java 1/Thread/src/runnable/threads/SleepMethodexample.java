package runnable.threads;

public class SleepMethodexample {

	public static void main(String[] args) {

				
				Runnable r=()->{
					
					try {
						Thread.sleep(10000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					  
				
	                for (int i=0;i<=20;i++) {
					
					System.out.println("First thread runnning");
				}

			};
			
			
			Runnable r1=()->{
				
				  
				for (int i=0;i<=20;i++) {
				
				System.out.println("second thread runnning");
			}

		};

		Runnable r2=()->{
			
			for (int i=0;i<=20;i++) {
			
			System.out.println("Third thread runnning");
		}

		};


		Thread a=new Thread(r);
		Thread a1=new Thread(r1);
		Thread a2=new Thread(r2);

		a.start();
		a1.start();
		a1.setPriority(10);

		a2.start();

}
		
			
}


