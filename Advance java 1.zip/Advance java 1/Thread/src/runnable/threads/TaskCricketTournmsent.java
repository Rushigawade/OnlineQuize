package runnable.threads;

import java.util.*;

public class TaskCricketTournmsent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Welcome cricket tournament");
		
		System.out.println("your pass is vip please enter  1 , pass is normal then press any no");
		
	     int pass=sc.nextInt();
		
	try {
		if (pass==1)
	
		{
			Runnable r1=()->{
				System.out.println("vip ticket so please seat s reserved");
			};
			
			Thread a1=new Thread(r1);
			a1.start();
			a1.setPriority(1);
			a1.getPriority();
			System.out.println("priority is  "+	a1.getPriority());
		}
		else
		{
			Runnable r2=()->{
				System.out.println("Noraml ticket so please seat s reserved");
			};	
			
			Thread a2=new Thread(r2);
			a2.start();
			a2.setPriority(2);
		System.out.println(	"priority is a2 "+a2.getPriority());
			
			
		} }
		catch(Exception e)
		{
			
		} finally {
			sc.close();
	}
	

	}

}
