package runnable.threads;

public class ThreadMethods {

	public static void main(String[] args) {
		
		Runnable r1=()->{
			
			for (int i=0;i<=10;i++)
			{
				System.out.println("First thread running");
			}
			
		};
		
		
        Runnable r2=()->{
			
			for (int i=0;i<=10;i++)
			{
				System.out.println("second thread running");
			}
			
		};
		
		
      Runnable r3=()->{
			
			for (int i=0;i<=10;i++)
			{
				System.out.println("Third thread running");
			}
			
		};
		
		
		
       Runnable r4=()->{
			
			for (int i=0;i<=10;i++)
			{
				System.out.println("Fourth thread running");
				
			}
			
		};
		
		
		Thread a1=new Thread(r1);
		Thread a2=new Thread(r2);
		Thread a3=new Thread(r3);
		Thread a4=new Thread(r4);
		
		
		a1.start();
		System.out.println("default name is a1"+ a1.getName());
		System.out.println("id is a1  "+a1.getId());
		a1.setName("Rushi");
		System.out.println("new set name is"+ a1.getName());
		
		System.out.println("priority of thread a1 is "+ a1.getPriority());
		
		a1.setPriority(9);
		System.out.println("new priority of thread a1 is "+ a1.getPriority());
		
		
		
		

		a2.start();
		System.out.println("default name is a2"+ a2.getName());
		System.out.println("id is a2  "+a2.getId());
		a2.setName("Rushi");
		System.out.println("new set name is"+ a2.getName());
		
		System.out.println("priority of thread a2 is "+ a2.getPriority());
		
		a2.setPriority(7);
		System.out.println("new priority of thread a2 is "+ a2.getPriority());
		

	}

}
