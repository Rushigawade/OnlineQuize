package com.raceCondition;

public class Raceconditionexample {
	
	static int x=0;
	
	public void increament()
	{
		x++;
	}
	
	public void decrement()
	{
		x--;
	}
	
	public void display()
	{
		System.out.println(x);
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Raceconditionexample r=new Raceconditionexample();
		
		Runnable r1=()->{
			
		r.increament();
		r.display();
		};
		
      
		Runnable r2=()->{
			r.decrement();
			r.display();
		};
		
		Thread a=new Thread(r1);
		a.start();
		
		Thread a1=new Thread(r2);
		a1.start();
				
	}

}
