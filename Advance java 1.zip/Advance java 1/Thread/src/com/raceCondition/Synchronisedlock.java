package com.raceCondition;

public class Synchronisedlock {
	
	static String s = "hii" ;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		Runnable r1 = () ->
				{
			synchronized (s) {
			
				System.out.println("Thread 1 locking");
				
				s=s+"java";
				
				System.out.println(s);
			}
			
			System.out.println("thread 1 released the lock");
				};
	
			Runnable r2 = () ->
			{
		synchronized (s) {
		
			System.out.println("Thread 2 locking");
			
			s=s+"Python";
			
			System.out.println(s);
		}
		
		System.out.println("Thread 2 released the lock");
			
					
				};
				
				
				Thread a=new Thread(r1);
				Thread a1=new Thread(r2);
				
				a.start();
				a1.start();

				
}
	}
