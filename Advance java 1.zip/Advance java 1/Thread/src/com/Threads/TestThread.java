package com.Threads;

public class TestThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FirstThread f1=new FirstThread();
		f1.start();
		
		SecondThread f2=new SecondThread();
		f2.start();
		

	}

}
