package com.Test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Example")
public class Example extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
    public Example() {
        System.out.println("constructor execute");  // 1 constructor execute
    }

	@Override
	public void destroy() {
		System.out.println("Destroy method execute");
	}


    @Override
	public void init() throws ServletException {
		System.out.println("init method execute");    // 2 init method execute
	}


protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		System.out.println("in service method");        // 3 output
	PrintWriter printWriter	=response.getWriter();
	
	printWriter.print("thise is first servalet program");
	}

}
