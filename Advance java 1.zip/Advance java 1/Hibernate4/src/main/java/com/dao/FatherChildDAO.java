package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dto.ChildDTO;
import com.dto.FatherDTO;

public class FatherChildDAO {

	private static EntityManagerFactory factory;
	private static EntityManager manager;
	private static EntityTransaction transaction;

	private static void openConnection() {

		factory = Persistence.createEntityManagerFactory("hibernate4");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();

	}

	private static void closeConnections() {
		factory.close();
		manager.close();

		try {
			transaction.rollback();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("transaction is commited");
		}

	}

	public static void main(String[] args) {
		
		openConnection();
		transaction.begin();
		
		ChildDTO child=new ChildDTO();
		child.setName("Vrushali");
		child.setAge(4);
		
		FatherDTO father=new FatherDTO();
		father.setName("Rushi");
		father.setAge(35);
		father.setChild(child);
		
		manager.persist(child);
		manager.persist(father);
		transaction.commit();
		closeConnections();

	}

}
