package com.dependancyinjection.spring.property.SpringCore2;

public class Bank {

	private String bank;
	private int customer;
	private String IFSCcode;

	@Override
	public String toString() {
		return "Bank [bank=" + bank + ", customer=" + customer + ", IFSCcode=" + IFSCcode + "]";
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public int getCustomer() {
		return customer;
	}

	public void setCustomer(int customer) {
		this.customer = customer;
	}

	public String getIFSCcode() {
		return IFSCcode;
	}

	public void setIFSCcode(String iFSCcode) {
		IFSCcode = iFSCcode;
	}

}
