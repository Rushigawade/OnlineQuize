package com.dependancyinjection.spring.property.SpringCore2;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BankTest {

	public static void main(String[] args) {
		

		
		ClassPathXmlApplicationContext cpx = new ClassPathXmlApplicationContext("com/dependancyinjection/spring/property/SpringCore2/springcoreconfi.xml");
		
		Bank bank=(Bank) cpx.getBean("bank");               //copy qualified name of spring core comnfiguration
		
		System.out.println(bank);
	}

}
