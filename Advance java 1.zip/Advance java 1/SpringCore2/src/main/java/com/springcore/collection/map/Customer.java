package com.springcore.collection.map;

import java.util.Map;

public class Customer {
	
	private String name;
	private Map<Integer,String>product;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Map<Integer, String> getProduct() {
		return product;
	}
	public void setProduct(Map<Integer, String> product) {
		this.product = product;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", product=" + product + "]";
	}
	
	

}
