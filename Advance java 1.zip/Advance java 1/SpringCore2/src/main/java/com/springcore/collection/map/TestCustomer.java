package com.springcore.collection.map;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestCustomer {

	public static void main(String[] args) {
		
	ClassPathXmlApplicationContext ctx	=new ClassPathXmlApplicationContext("com/springcore/collection/map/CustomerConfi.xml");
    
	Customer cus=(Customer) ctx.getBean("Customer");

     System.out.println(cus);
	}

}
