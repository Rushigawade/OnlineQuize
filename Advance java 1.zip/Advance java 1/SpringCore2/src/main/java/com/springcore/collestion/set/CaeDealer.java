package com.springcore.collestion.set;

import java.util.Set;

public class CaeDealer {
	
	private String Name;
	private Set<String> model;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Set<String> getModel() {
		return model;
	}
	public void setModel(Set<String> model) {
		this.model = model;
	}
	@Override
	public String toString() {
		return "CaeDealer [Name=" + Name + ", model=" + model + "]";
	}
	
	

}
