package com.springcore.collestion.set;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springcore.collection.list.Hospital;

public class TestCaeDealer {

	public static void main(String[] args) {
		
		
		ClassPathXmlApplicationContext ctx	= new ClassPathXmlApplicationContext("com/springcore/collestion/set/Caeconfig.xml");
		
		
		
		CaeDealer hos=(CaeDealer)ctx.getBean("CaeDealer");
		System.out.println(hos);

	}

}
