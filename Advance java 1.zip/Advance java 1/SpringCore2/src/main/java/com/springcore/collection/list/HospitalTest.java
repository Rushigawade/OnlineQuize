package com.springcore.collection.list;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class HospitalTest {

	public static void main(String[] args) {

		
	ClassPathXmlApplicationContext ctx	= new ClassPathXmlApplicationContext("com/springcore/collection/list/hospitalconfig.xml");
	
	
	
	Hospital hos=(Hospital)ctx.getBean("hospital");
	System.out.println(hos);
	
	
	
	

	}

}
