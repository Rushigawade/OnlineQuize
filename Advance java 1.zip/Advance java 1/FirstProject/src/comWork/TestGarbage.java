package comWork;

public class TestGarbage {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		Student obj=new Student("Baburao",17);
		
		System.out.println(obj.name);
		
		obj=null;                              //getting error null pointer exception due to passing null value address 
		System.gc();
		
		System.out.println(obj.name);  
	}

}
