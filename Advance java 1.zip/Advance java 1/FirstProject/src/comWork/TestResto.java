package comWork;

public class TestResto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
