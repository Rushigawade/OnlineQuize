package comWork;

public class simple {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Hello");
		System.out.println("hey hemendra sir talk talk");  //sysout control space print line system.out.println();
		                                                   //Main control space  create main method 
		
		
		
		
		
		
	}

}
