package com.DAO;

public class SongsDAO {

	
	public String viewAllSongs()
	{
		return null;
		
	}
	
	
	public String addSongs()
	{
		return null;
	}
	
	
	public String removeSongs() {
		
		return null;
	}
	
	
	public String updateSong() {
		
		return null;
	}
	
	public String playRandomSong() {
		
		return null;
	}
	
	public String selectSongToPlay() {
		
		return null;
	}
	
	public String playAllSongs() {
       
		return null;
	}
	
	public String exit() {
		
		return null;
	}
	
	
	
	public static void main(String[] args) {
		
	}
}
