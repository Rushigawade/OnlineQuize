package com.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
@Data
@Entity
@Table(name="Banks")
public class BankDTO {
	
	@Column(name="bank_name")
	private String bankName;
	private String customerName;
	@Id
	private String accountNo;
	private long phoneNo;
	private String address;
	
	
	

}
