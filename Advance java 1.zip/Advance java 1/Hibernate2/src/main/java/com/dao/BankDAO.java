package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dto.BankDTO;

public class BankDAO {
	private static EntityManagerFactory entityManagerFactory;
	private static EntityManager entityManager;
	private static EntityTransaction entityTransaction;

	private static void openConnection() {

		entityManagerFactory = Persistence.createEntityManagerFactory("hibernate2");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();

	}

	private static void closeConnections() {
		entityManagerFactory.close();
		entityManager.close();

		try {
			entityTransaction.rollback();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("can not rollback if has already commited");
		}

	}

	public static void main(String[] args) {

		openConnection();

		entityTransaction.begin();
		
		BankDTO bank=new BankDTO();
		bank.setAccountNo("45kg");
		bank.setAddress("pune");
		bank.setBankName("Maharashtra");
		bank.setCustomerName("Rushi");
		bank.setPhoneNo(7558769389l);
		
		System.out.println("1");
		
		bank.setAccountNo("hfdc5451");
		bank.setAddress("ambegaon");
		bank.setCustomerName("ajinath");
		bank.setPhoneNo(755845l);
		bank.setBankName("india");
		
		System.out.println("2");
		
		bank.setAccountNo("hhjgdc5451");
		bank.setAddress("egaon");
		bank.setCustomerName("jinath");
		bank.setPhoneNo(745l);
		bank.setBankName("pudia");
		
		System.out.println("3");
		
		bank.setAccountNo("5451");
		bank.setAddress("aon");
		bank.setCustomerName("nath");
		bank.setPhoneNo(589645l);
		bank.setBankName("ia");
		
		System.out.println("4");
		
		
		entityManager.persist(bank);

		entityTransaction.commit();

		closeConnections();
}
	
}