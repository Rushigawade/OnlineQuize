package com.serilization;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerilizationExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String path="C:\\Users\\admin\\Desktop\\Rushi";
		
		File f=new File("path");
		
		FileOutputStream fos=null;
		ObjectOutputStream os=null;
		
		Employee emp=new Employee("babu","babu@gmail.com");
		
		try {
			fos=new FileOutputStream(f);
			
			try {
				os=new ObjectOutputStream(fos);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				os.writeObject(emp);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("object is serialised");
		
		} catch (FileNotFoundException e) {
		e.printStackTrace();
	} 
	
	finally {
			try {
				fos.close();
				os.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		

	}

}
