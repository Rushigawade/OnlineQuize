package com.jdbc.connectivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class Jdbcexample {
	
	static Connection connnection;
	static Statement statement;
    static ResultSet resultset;
    
    public static void main(String[] args) {
		
    	try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			connnection =DriverManager.getConnection("jdbc:mysql://localhost:3306/hr?user=root&password=8600460095");
			statement = connnection.createStatement();
			String query = " select * from countries";
			resultset= statement.executeQuery(query);
			
			while (resultset.next()) {
				
				System.out.println(resultset.getString(1) + "|" + resultset.getString(2)+"|" + resultset.getString(3));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	if (connnection!=null) {
    		
			try {
				connnection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if (statement!= null) {
				
				try {
					statement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(resultset != null) {
				
				try {
					resultset.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
