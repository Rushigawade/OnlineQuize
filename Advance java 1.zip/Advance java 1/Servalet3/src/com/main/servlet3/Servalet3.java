package com.main.servlet3;

import javax.servlet.http.HttpServlet;

public class Servalet3 extends HttpServlet {
	
	

}
