package open.closed.principal;

public class GoldLoan extends Customer{
	
	public boolean isLoyal() {
		
		
		return false;
	}

}
