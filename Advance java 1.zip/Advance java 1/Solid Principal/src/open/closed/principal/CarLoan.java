package open.closed.principal;


     public class CarLoan extends Customer{

		public boolean isLoyal() {
	       return false;		
		}

	}


