package open.closed.principal;

public class HomeLoan extends Customer{
	
	public boolean isLoyal() {

		return true;
	
	}}
