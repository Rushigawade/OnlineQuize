package open.closed.principal;

public class Driver1 {
	
	public static void main(String[] args) {
		DiscountCheck discountcheck=new DiscountCheck();
		
		Customer c1=new CarLoan();
		double finalprice=discountcheck.calcutor(c1);
		System.out.println("discount after loyality "+finalprice);
		
		Customer c2=new HomeLoan();
		double finalp =discountcheck.calcutor(c2);
		System.out.println("Discount after loyality "+finalp);
		
		
		Customer c3 =new GoldLoan();
		double finallp =discountcheck.calcutor(c3);
		System.out.println("discount after loyality "+finallp);
		
		
	}

}
