package open.closed.principal;

public abstract class Customer {
	
	abstract public boolean isLoyal();

	

}
