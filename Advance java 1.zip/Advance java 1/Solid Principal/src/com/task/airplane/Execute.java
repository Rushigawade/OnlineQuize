package com.task.airplane;

public class Execute {

	public static void main(String[] args) {
		
		
		Flight f1=new Flight("kingfisher",12145,422,"11:43","15:30");
		Passengers ps = new Passengers("john doe",123456789,26,"Delhi");
		
		f1.display();
		ps.display();
		
		
		f1.setFname("INDIANS");
		f1.setFno(145487);
		f1.setPassengers(260);
		f1.setDepart("16:00");
		f1.setArrive("09:30");
		
		
		ps.setName(" Rushi");
		ps.setContact(758769621);
		ps.setAge(24);
		ps.setCity("pune");
		
		
		System.out.println();
		f1.display();
		ps.display();

	}

}
