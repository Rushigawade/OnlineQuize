package com.task.airplane;

public class Passengers {
	
	private String name;
	private long contact;
	private int age;
	private String city;
	
	
	
	public void display() {
		
		System.out.println("Details of passanger");
		System.out.println("Name "+name);
		System.out.println("contact "+contact);
		System.out.println("Age  "+age);
		System.out.println("Destination  "+ city);
	}
	
	public Passengers(String name, long contact, int age, String city) {
		super();
		this.name = name;
		this.contact = contact;
		this.age = age;
		this.city = city;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getContact() {
		return contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
}
