package com.task.airplane;

public class Flight {
	
	private String fname;
	private int fno;
	private int passengers;
	private String arrive;
	private String depart;
	
	
	public void display()
	{
		System.out.println("Name of Flight is "+ fname);
		System.out.println("Flight numberb is "+ fno);
		System.out.println("Total no of passengers "+passengers);
		System.out.println("Time of departure "+ depart);
		System.out.println("Time of arrival "+ arrive);
	}
	
	
	public Flight(String fname, int fno, int passengers, String arrive, String depart) {
		super();
		this.fname = fname;
		this.fno = fno;
		this.passengers = passengers;
		this.arrive = arrive;
		this.depart = depart;
}



	public String getFname() {
		return fname;
	}



	public void setFname(String fname) {
		this.fname = fname;
	}



	public int getFno() {
		return fno;
	}



	public void setFno(int fno) {
		this.fno = fno;
	}



	public int getPassengers() {
		return passengers;
	}



	public void setPassengers(int passengers) {
		this.passengers = passengers;
	}



	public String getArrive() {
		return arrive;
	}



	public void setArrive(String arrive) {
		this.arrive = arrive;
	}



	public String getDepart() {
		return depart;
	}



	public void setDepart(String depart) {
		this.depart = depart;
	}
	

}
