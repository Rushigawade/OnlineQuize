package com.solidprincipaltask;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class BookExample {
	
	String name;
	int id;
	double price;
	int copy;
	String x,y,z;
	
	public BookExample(String name, int id, double price, int copy) {
		super();
		this.name = name;
		this.id = id;
		this.price = price;
		this.copy = copy;
	}
	
	public void display() {
		
		if(copy>=5) {
			price*=0.1;
		}
		
		x="Name of book is "+ name + "\n";
		y="Book id is "+ id + "\n";
		z="Total price is "+ copy*price +"\n";
	
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Welcome to book shop \n Which book you want to purchase?");
		
		String n=sc.nextLine();
		
		System.out.println("how many copies you want?");
		
		int  a=sc.nextInt();
		BookExample be=new BookExample(n,103,432.32,a);
		be.display();
		
	String path="C:\\Users\\admin\\Desktop\\Rushi\\fi.txt";
		
		File f=new File(path);
		
		
		try {
			f.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		FileWriter fw =null;
		
		try {
			fw=new FileWriter(f);
			fw.write(be.x+be.y+be.z);
			fw.flush();
			System.out.println("invoice is printed");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		sc.close();
		
	}

}
