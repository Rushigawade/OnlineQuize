package com.LiskoSubstituionPrincipal;

public class Sparrow extends Bird{


	public void fly() {
		// TODO Auto-generated method stub
		
		System.out.println("Sparrow is flying");
		
	}

}
