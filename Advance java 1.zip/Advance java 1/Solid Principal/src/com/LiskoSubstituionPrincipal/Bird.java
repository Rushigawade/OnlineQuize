package com.LiskoSubstituionPrincipal;

public abstract class Bird implements Animal {
	
	abstract public void fly();

	

	

}
