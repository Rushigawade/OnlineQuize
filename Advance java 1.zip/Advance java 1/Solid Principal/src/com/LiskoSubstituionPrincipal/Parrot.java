package com.LiskoSubstituionPrincipal;

public class Parrot extends Bird{

	
	public void fly() {
		// TODO Auto-generated method stub
		
		System.out.println("Parrot is flying");
		
	}
	
}
