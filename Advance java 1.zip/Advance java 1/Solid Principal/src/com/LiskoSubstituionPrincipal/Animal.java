package com.LiskoSubstituionPrincipal;

public interface Animal {


}
