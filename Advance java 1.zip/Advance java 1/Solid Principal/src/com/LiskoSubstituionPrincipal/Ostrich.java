package com.LiskoSubstituionPrincipal;

public class Ostrich extends Bird{
	
	public void fly() {
		System.out.println("Ostrich is flying");
	}

}
