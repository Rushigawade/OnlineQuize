package com.InterfaceSeggregationPrincipal;

public class Hp implements Scan,Print {

	@Override
	public void print() {
		System.out.println("Hp provide print");
		
	}

	@Override
	public void scan() {
		System.out.println("Hp provide scan");
		
	}

}
