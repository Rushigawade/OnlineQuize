package com.InterfaceSeggregationPrincipal;

public interface Fax {

	
	void fax();
}
