package com.InterfaceSeggregationPrincipal;

public interface Scan {
	
	void scan();

}
