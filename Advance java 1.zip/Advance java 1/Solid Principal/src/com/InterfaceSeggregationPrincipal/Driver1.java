package com.InterfaceSeggregationPrincipal;

public class Driver1 {

	public static void main(String[] args) {
		
	
		
		Hp hp = new Hp();
		hp.scan();
		hp.print();
		
		
	}
	
}
