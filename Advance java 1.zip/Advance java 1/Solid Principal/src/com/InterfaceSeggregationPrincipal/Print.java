package com.InterfaceSeggregationPrincipal;

public interface Print {
	
	void print();

}
