package com.InterfaceSeggregationPrincipal;

public class Epson implements Print,Fax,Scan {

	@Override
	public void scan() {
		System.out.println("Epson provide scan");
		
	}

	@Override
	public void fax() {
		System.out.println("Epson provide fax");
		
	}

	@Override
	public void print() {
		System.out.println("Epson provide print");
		
	}

}
