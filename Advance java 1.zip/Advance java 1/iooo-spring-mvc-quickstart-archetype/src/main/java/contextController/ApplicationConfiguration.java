package contextController;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfiguration {

}
