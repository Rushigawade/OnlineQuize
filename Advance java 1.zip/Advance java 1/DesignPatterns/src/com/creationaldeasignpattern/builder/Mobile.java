package com.creationaldeasignpattern.builder;

public class Mobile {
	
	String model;
	int ram;
	int rom;
	String processor;
	int battery;
	int frontcam;
	int rearcam;
	double price;
	String color;
	boolean fingerprint;
	
	public Mobile(String model, int ram, int rom, String processor, int battery, int frontcam, int rearcam,
			double price, String color, boolean fingerprint) {
		super();
		this.model = model;
		this.ram = ram;
		this.rom = rom;
		this.processor = processor;
		this.battery = battery;
		this.frontcam = frontcam;
		this.rearcam = rearcam;
		this.price = price;
		this.color = color;
		this.fingerprint = fingerprint;
	}
	
	

	//public Mobile(int battery2, String brand, String color2, boolean fingerprint2, int frontcam2, double price2,
			//double price3, String processor2, int ram2, int rearcam2, int rom2) {
		// TODO Auto-generated constructor stub
	//}

	@Override
	public String toString() {
		return "Mobile [model=" + model + ", ram=" + ram + ", rom=" + rom + ", processor=" + processor + ", battery="
				+ battery + ", frontcam=" + frontcam + ", rearcam=" + rearcam + ", price=" + price + ", color=" + color
				+ ", fingerprint=" + fingerprint + "]";
	}

}
