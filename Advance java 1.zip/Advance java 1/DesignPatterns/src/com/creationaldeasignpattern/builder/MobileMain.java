package com.creationaldeasignpattern.builder;

public class MobileMain {

	public static void main(String[] args) {
		
		
		Mobile mobile=new MobileBuilder().setBrand("Apple").setColor("pink").setPrice(150.0).build();
		System.out.println(mobile);

	}

}
