package com.creationaldeasignpattern.builder;

public class MobileBuilder {
	
	String model;
	int ram;
	int rom;
	String processor;
	int battery;
	int frontcam;
	int rearcam;
	double price;
	String color;
	boolean fingerprint;
	
	
	
	public MobileBuilder setBrand(String brand) {
		this.model = brand;
		return this;
	}
	public MobileBuilder setRam(int ram) {
		this.ram = ram;
		return this;
	}
	public MobileBuilder setRom(int rom) {
		this.rom = rom;
		return this;
	}
	public MobileBuilder setProcessor(String processor) {
		this.processor = processor;
		return this;
	}
	public MobileBuilder setBattery(int battery) {
		this.battery = battery;
		return this;
	}
	
	public MobileBuilder setFrontcam(int frontcam) {
		this.frontcam = frontcam;
		return this;
	}
	public MobileBuilder setRearcam(int rearcam) {
		this.rearcam = rearcam;
		return this;
	}
	public MobileBuilder setPrice(double price) {
		this.price = price;
		return this;
	}
	public MobileBuilder setColor(String color) {
		this.color = color;
		return this;
	}
	public MobileBuilder setFingerprint(boolean fingerprint) {
		this.fingerprint = fingerprint;
		
		return this;
	}
	public Mobile build() {
		Mobile mobile=new Mobile(this.model,this.ram, this.rom, this.processor, this.battery,this.frontcam, this.rearcam,
				this.price, this.color, this.fingerprint);
		return mobile;
		
	
	}
	}
	
	


