package com.test;

public class Emp {
	
	void sal() {
		
		System.out.println("4000");
	}

}

class Emp1 extends Emp{
	
	void bonus() {
		System.out.println("5000");
	}
	
	public static void main(String[] args) {
		
		Emp1 E1=new Emp1();
		E1.bonus();
		E1.sal();
	}
}
