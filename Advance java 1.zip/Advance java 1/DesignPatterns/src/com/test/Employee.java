package com.test;

public class Employee {
	
	private int empid,studid;
	

	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}


	public int getStudid() {
		return studid;
	}


	public void setStudid(int studid) {
		this.studid = studid;
	}


	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", studid=" + studid + "]";
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
Employee obj=new Employee();
obj.setEmpid(45);
obj.setStudid(87);
System.out.println(obj);

	}

}
