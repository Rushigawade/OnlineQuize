package com.creationaldesignpattern.singalton;

public class Democlass {

	
	private static Democlass democlass;
	
	static int count;
	
	private Democlass() {
		System.out.println("object created  "+count+"  times");
	}
	
	public static Democlass getobject() {
		
		if (democlass==null) {
			
			count++;
			democlass=new Democlass();
			System.out.println("objet created method");
			
			return democlass;
		}
		
		System.out.println("object creation method");
		return democlass;
		
	}
}
