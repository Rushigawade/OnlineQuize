package com.creationaldesignpattern.singalton;

public class DemoTest {

	public static void main(String[] args) {
	
		
		Democlass.getobject();
		Democlass.getobject();
		Democlass.getobject();

	}

}
