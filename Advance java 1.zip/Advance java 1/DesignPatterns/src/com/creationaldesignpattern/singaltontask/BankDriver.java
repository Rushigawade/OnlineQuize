package com.creationaldesignpattern.singaltontask;

public class BankDriver {

	public static void main(String[] args) {
		
		
		Bank.getObject();
		Bank.getObject();
		Bank.getObject();

	}

}
