package com.creationaldesignpattern.singaltontask;

public class Bank {
	
	private static Bank bank;
	static int count;
	
	private Bank() {
		System.out.println("object created "+count+ "times(s)");
	}
	
	public static Bank getObject() {
		if(bank==null)
		{
			count++;
			bank=new Bank();
			System.out.println("object created method");
			return bank;
		}
		System.out.println("object created method");
		return bank;
	}

}
