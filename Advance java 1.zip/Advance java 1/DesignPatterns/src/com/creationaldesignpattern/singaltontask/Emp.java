package com.creationaldesignpattern.singaltontask;

import java.util.Scanner;

public class Emp {                        //only practice eg

	public static void main(String[] args) {
		
		int id;
		String name;
		String address;
		String dream;
		
		Scanner in=new Scanner(System.in);
		
		System.out.println("Enter employee name");
		name=in.nextLine();
		
		System.out.println("Enter employee address");
		address=in.nextLine();
		
		System.out.println("Enter employee id");
		id=in.nextInt();  
		
		}

}
