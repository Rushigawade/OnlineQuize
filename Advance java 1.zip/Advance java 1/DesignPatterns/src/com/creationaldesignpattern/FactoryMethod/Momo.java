package com.creationaldesignpattern.FactoryMethod;

public class Momo implements Fastfood {

	@Override
	public void order() {
	
		System.out.println("bhaiyya thoda Mayonnaise");
		
	}

}
