package com.creationaldesignpattern.FactoryMethod;

import java.util.Scanner;

public class FastfoodDriver {
	
	static int choice;
	static Scanner sc=new Scanner(System.in);
	
	static Fastfood fastfood;
	

	public static void main(String[] args) {
		
		try {
		factory().order();
		}
		catch(NullPointerException e)
		{
			System.out.println("nothing order");
		}
		
	}




public static Fastfood factory() {
	System.out.println("choose your food from many  \n1.Panipuri\n2.Momo\n");
	
	choice=sc.nextInt();
	switch (choice) {
	
		
		case 1:
			fastfood=new Panipuri();
		     return fastfood;
		     
		     
		     case 2:
		    	 fastfood=new Momo();
		         return fastfood;
		     
		default:
			System.out.println("wrong choice");
	}
	return fastfood;
}
}
