package com.creationaldesignpattern.FactoryMethod;

public class Panipuri implements Fastfood {

	@Override
	public void order() {
	
		System.out.println("bhaiyya thoda tikha banao");
		
	}

}
