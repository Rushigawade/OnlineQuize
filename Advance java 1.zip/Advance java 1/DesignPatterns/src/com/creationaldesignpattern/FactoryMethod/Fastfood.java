package com.creationaldesignpattern.FactoryMethod;

public interface Fastfood {
	
	void order();

}
