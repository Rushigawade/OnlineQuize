package com.creationaldesignpattern.factory.task;

public class Shubham implements Users {

	@Override
	public void login() {
	
		System.out.println("Welcome shubham");
		
	}

}
