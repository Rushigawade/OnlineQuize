package com.creationaldesignpattern.factory.task;

public interface Users {
	
	void login();

}
