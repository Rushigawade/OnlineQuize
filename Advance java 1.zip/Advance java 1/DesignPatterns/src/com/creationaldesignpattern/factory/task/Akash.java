package com.creationaldesignpattern.factory.task;

public class Akash implements Users {

	@Override
	public void login() {
		
		System.out.println("Welcome Akash");
		
	}

}
