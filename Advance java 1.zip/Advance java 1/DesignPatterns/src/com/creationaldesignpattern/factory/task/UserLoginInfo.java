package com.creationaldesignpattern.factory.task;
import java.util.Scanner;

public class UserLoginInfo {
	
	static int choice;
	static Scanner sc=new Scanner(System.in);
	static Users users;

	public static void main(String[] args) {
		
		
		try {
			
		factory().login();
		
		}catch(NullPointerException E) {
			
			System.out.println("Nothimg ordered");
		}
          
	}
	
	public static Users factory() {
		System.out.println("Select usres from below \n1.rushi\n2.shubham.\n3.akash");
		choice = sc.nextInt();
		
		switch(choice) {
		
		case 1:
			users=new Rushi();
			return users;
			
			
		case 2:
			users=new Shubham();
			return users;
			
		case 3:
			users=new Akash();
			return users;
			
			
			default:
				System.out.println("Invalid choice");
				
		}
		return users;
	}

}
