package com.creationaldesignpattern.factory.task;

public class Rushi implements Users {

	@Override
	public void login() {
		
		System.out.println("Welcome Rushi");
		
	}

}
