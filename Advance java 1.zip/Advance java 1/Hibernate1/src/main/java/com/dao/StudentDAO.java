package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dto.StudentDTO;

public class StudentDAO {
	private static EntityManagerFactory entityManagerFactory;
	private static EntityManager entityManager;
	private static EntityTransaction entityTransaction;

	private static void openConnection() {

		entityManagerFactory = Persistence.createEntityManagerFactory("hibernate1");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();

	}

	private static void closeConnections() {
		entityManagerFactory.close();
		entityManager.close();

		try {
			entityTransaction.rollback();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("can not rollback if has already commited");
		}

	}

	public static void main(String[] args) {

		openConnection();

		entityTransaction.begin();

		StudentDTO dto = new StudentDTO();
		dto.setRollno(45);
		dto.setName("Rushi");
		dto.setEmailid("rushi@123");
		dto.setPhoneno(755587693);
		dto.setAddress("baradgaon");
		

		
		dto.setRollno(46);
		dto.setName("Akash");
		dto.setEmailid("akash@gmail.com");
		dto.setPhoneno(8600460095l);
		dto.setAddress("Rashin");
		
		
		dto.setRollno(47);
		dto.setName("Shubham");
		dto.setEmailid("shubzz@gmail.com");
		dto.setPhoneno(9970507109l);
		dto.setAddress("pune");
		
		
		//update value from the table and delete
		StudentDTO find=entityManager.find(StudentDTO.class,45);
		System.out.println(find);
		find.setName("Sachin");
		entityManager.remove(find);
		
		entityManager.persist(dto);

		entityTransaction.commit();

		closeConnections();

	}

}
