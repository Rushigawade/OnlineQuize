package com.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Entity
public class StudentDTO {
	
	@Id
	private int rollno;
	private String name;
	private String emailid;
	private long phoneno;
	private String address;

	@Override
	public String toString() {
		return "StudentDTO [rollno=" + rollno + ", name=" + name + ", emailid=" + emailid + ", phoneno=" + phoneno
				+ ", address=" + address + "]";
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public long getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	
			
			}
}