package com.jpql.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jpql.dto.EmployeeDTO;

public class EmployeeDAO {
	
	private static EntityManagerFactory factory;
	private static EntityManager manager;
	private static EntityTransaction transaction;

	private static void openConnection() {

		factory = Persistence.createEntityManagerFactory("hibernate9");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();

	}

	private static void closeConnections() {
		factory.close();
		manager.close();

		try {
			transaction.rollback();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("transaction is commited");
		}

	}

	public static void main(String[] args) {
		
		openConnection();
		transaction.begin();
		
		EmployeeDTO employee1=new EmployeeDTO();
		employee1.setName("Rushi");
		employee1.setEmail("rushi@123");
		employee1.setPhoneNo(755876455);
		employee1.setSalary(30000);
		
		manager.persist(employee1);
		
		EmployeeDTO employee2=new EmployeeDTO();
		employee2.setName("Akash");
		employee2.setEmail("Akash@123");
		employee2.setPhoneNo(457876455);
		employee2.setSalary(35000);
		
		manager.persist(employee2);
		
		EmployeeDTO employee3=new EmployeeDTO();
		employee3.setName("Shubha");
		employee3.setEmail("Shubh@123");
		employee3.setPhoneNo(99645155);
		employee3.setSalary(26000);
		
		manager.persist(employee3);
		
		EmployeeDTO employee4=new EmployeeDTO();
		employee4.setName("gushi");
		employee4.setEmail("gui@123");
		employee4.setPhoneNo(89758764);
		employee4.setSalary(3000);
		
		transaction.commit();
		transaction.begin();
		
		System.out.println("display---------------------------------");
		
		//String jpql="select * from EmployeeDTO c"
		//		Query query=manager.createQuery(jpql);
		
		
		
		

}
