package com.jpql.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "Employee_Data")
public class EmployeeDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Employee_id")
	private int id;

	@Column(name="Employee_Name")
	private String name;

	@Column(name="Employee_Email")
	private String email;

	@Column(name="Employee_Salary")
	private double salary;

	@Column(name="Employee_PhoneNo")
	private long phoneNo;

}
