package com.DTO;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;




@Data
@Entity
@Table(name="Employees")
public class EmployeeDTO {
	
	@Id 
	private double empno;
	private String empname;
	
	@Column(name="com_name")
	private String companyname;
	private String emailid;
	private int sal;

}
