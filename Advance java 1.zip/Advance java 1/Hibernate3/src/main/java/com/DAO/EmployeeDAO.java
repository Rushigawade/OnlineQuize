package com.DAO;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.DTO.EmployeeDTO;

public class EmployeeDAO {
	private static EntityManagerFactory entityManagerFactory;
	private static EntityManager entityManager;
	private static EntityTransaction entityTransaction;

	private static void openConnection() {

		entityManagerFactory = Persistence.createEntityManagerFactory("hibernate3");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();

	}

	private static void closeConnections() {
		entityManagerFactory.close();
		entityManager.close();

		try {
			entityTransaction.rollback();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("can not rollback if has already commited");
		}

	}

	public static void main(String[] args) {
	
		openConnection();
		
		entityTransaction.begin();
		
		EmployeeDTO emp=new EmployeeDTO();
		emp.setEmpno(4564d);
		emp.setEmailid("rushi@123");
		emp.setSal(4000);
		emp.setEmpname("rushikesh");
		emp.setCompanyname("virtusa");
		
	    
		
		
		entityManager.persist(emp);

		entityTransaction.commit();

		closeConnections();

	}

}
